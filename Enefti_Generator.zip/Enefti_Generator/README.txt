

Welcome to Enefti Generator! Please read those instructions carefully to start generating your NFT's!

---- First Steps ----

Step 1. Configure settings in config.yaml.

Step 2. Organise Layers in the art-engine directory.

---- Organise Layers ----
Inside the art-engine directory, paste your assets into the folder "assets".
Inside of the folder, you can create your organised folders of layers to be used to create your images. 
It should look something like this:


└── assets/

    ├── Body/
    
    │   ├── Alien
    │   ├── Human
    │   ├── Robot
    │   └── Monster
    
    ├── Beard/
    
    │   ├── Long Beard
    │   ├── Short Beard
    │   ├── Cool Beard
    │   └── Pink Beard
    
    └── Eye Accessory/
        ├── Sunglasses
        ├── Eyepatch
        └── Visor
		
		In the config.yaml file add your layer folder names, exactly as they appear in your assets folder. 
		Place them in the order you wish to appear, e.g. Background, then Body, then Eye, Accessory etc.
		
		
---- Setting Rarities ----

The values in the rarities represent how often you want each layer to occur as a percentage out of 100.

For example, if you have two backgrounds, you may set the rarities to [80, 20].

The rarities should be in the same order as the layers are in the folder (usually alphabetical).

If the layer is not mandatory - e.g. a hat/accessory - add an extra value into rarities to represent the "None" value.

For example, if you have two hats, you could set the rarities as [60, 30, 10]. This means the first hat will occur 60% of the time, the second 30% of the time, and no accessory 10% of the time.


---- Running The Program ----

Inside of the Enefti_Generator folder, open a terminal and run python art-engine
Your images and metadata will start being created. Enjoy and good luck! 

